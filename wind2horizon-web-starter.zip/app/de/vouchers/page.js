export default function Vouchers() {
  return <div><h2>Vouchers</h2><p>Coming soon…</p></div>
}
