export default function Partner() {
  return <div><h2>Partner Upload</h2><p>Coming soon…</p></div>
}
